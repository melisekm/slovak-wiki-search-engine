from pyspark.sql import SparkSession
from wiki_parser import WikiParser

if __name__ == '__main__':
    spark_executor = "local[*]"

    spark = SparkSession \
        .builder \
        .appName("XML TEST") \
        .master(spark_executor) \
        .getOrCreate()

    df = spark.read.format("xml") \
        .options(charset='ISO-8859-1',
                 rowTag="page",
                 inferSchema=False) \
        .load("/user/root/sk_wikipedia_dump_small_1m.xml")
    df.printSchema()

    parser = WikiParser()

    data = (
        df.rdd
        .map(parser.parse_page)
        .filter(lambda x: x is not None)

    )
    data.saveAsTextFile("./sk_wikipedia_dump_small_1m_parsed.txt")

    spark.stop()
