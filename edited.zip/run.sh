set -e

if [ "$#" -ne 5 ]; then
    echo "Usage: run.sh <input_path> <output_path> <py_files.zip> <other_file,otherfile2> <main_script>"
    echo "Make sure conf.json is correctly configured"
    exit 1
fi

input_path=$1
output_path=$2
py_files=$3
other_files=$4
main_script=$5

#python3 -m venv melisekm_vinf
#source melisekm_vinf/bin/activate
#python3 -m pip install --upgrade --force pip

#pip install -r requirements.txt
#venv-pack -o pyspark_venv_melisek.tar.gz

../spark-3.3.1-bin-hadoop3/bin/spark-submit \
 --packages com.databricks:spark-xml_2.12:0.15.0 \
 --master mesos://147.213.75.180:5050 \
 --conf spark.executor.uri=hdfs://147.213.75.180:/user/selo/spark-3.3.1-bin-hadoop3.tgz \
 --archives hdfs://147.213.75.180:/user/hadmin/pyspark_venv_melisek.tar.gz#environment \
 --conf spark.executor.memory=26G \
 --conf spark.num.executors=13 \
 --py-files $py_files \
 --files=$other_files \
 $main_script $input_path $output_path

#hadoop fs -copyToLocal $output_path/data ./results

